import UIKit
import Firebase

class DetailViewController: UIViewController {
    
    @IBOutlet weak var realnametf: UITextView!
    @IBOutlet weak var friendscallmetf: UITextView!
    @IBOutlet weak var birthdaytf: UITextView!
    @IBOutlet weak var emailtf: UITextView!
    @IBOutlet weak var bestfriendtf: UITextView!
    @IBOutlet weak var happiestmomentoflifetf: UITextView!
    @IBOutlet weak var placeyouwanttoseetf: UITextView!
    @IBOutlet weak var favouritecolortf: UITextView!
    @IBOutlet weak var favouritesonftf: UITextView!
    @IBOutlet weak var favouritemovietf: UITextView!
    @IBOutlet weak var luckynumbertf: UITextView!
    @IBOutlet weak var goodthingsaboutyou: UITextView!
    @IBOutlet weak var badthingsaboutyoutf: UITextView!
    @IBOutlet weak var ifyouaregrantedthreewishestf: UITextView!
    @IBOutlet weak var lifeishellwithouttf: UITextView!
    @IBOutlet weak var worstmistaketf: UITextView!
    @IBOutlet weak var describewhatyoufeellikewakingtf: UITextView!
    @IBOutlet weak var yourcommentaboutmetf: UITextView!
    @IBOutlet weak var favouritequotetf: UITextView!

    var strrealname:String=""
    var strfriencall:String=""
    var strbirth:String=""
    var stremai:String=""
    var strbest:String=""
    var strhappi:String=""
    var strplace:String=""
    var strcolor:String=""
    var strsong:String=""
    var strmovie:String=""
    var strluckyno:String=""
    var strgoodthing:String=""
    var strbadthings:String=""
    var strthreewishes:String=""
    var strlifeishell:String=""
    var strwrostmistake:String=""
    var strdescribe:String=""
    var stryourcomment:String=""
    var strquote:String=""
   
    var ref = DatabaseReference.init()
    var arrayOfKeys = [String]()
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadFunctionality()
    }

    override func viewDidAppear(_ animated: Bool) {
        getKeys()
    }
    
    
    
    
    //MARK:load_functionality function
    func loadFunctionality(){
        realnametf.text = strrealname
        friendscallmetf.text=strfriencall
        birthdaytf.text=strbirth
        emailtf.text=stremai
        bestfriendtf.text=strbest
        happiestmomentoflifetf.text=strhappi
        placeyouwanttoseetf.text=strplace
        favouritecolortf.text=strcolor
        favouritesonftf.text=strsong
        favouritemovietf.text=strmovie
        luckynumbertf.text=strluckyno
        goodthingsaboutyou.text=strgoodthing
        badthingsaboutyoutf.text=strbadthings
        ifyouaregrantedthreewishestf.text=strthreewishes
        lifeishellwithouttf.text=strlifeishell
        worstmistaketf.text=strwrostmistake
        describewhatyoufeellikewakingtf.text=strdescribe
        yourcommentaboutmetf.text=stryourcomment
        favouritequotetf.text=strquote
        
        let trash = UIBarButtonItem(barButtonSystemItem: .trash, target: self, action: #selector(trashclicked))
        navigationItem.rightBarButtonItem = trash
        ref = Database.database().reference()
    }
    
    
    
    
    //MARK:get_keys function
    func getKeys(){
        self.arrayOfKeys.removeAll()
        self.ref.child("entryarray").observeSingleEvent(of: .value) { (snapshot) in
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot]{
                for snap in snapShot{
                    let key = snap.key
                    //print("key=",key)
                    self.arrayOfKeys.append(key)
                }
            }
        }
    }
    
    
    
    
    //MARK:trash_clicked function
    @objc func trashclicked(){
        print("trash")
        let selectedKey = arrayOfKeys[TableViewController.indpath]
        //        print("selected key = ",selectedKey)
        self.ref.child("entryarray").child(selectedKey).removeValue()
        self.navigationController?.popViewController(animated: true)
    }


}
