import UIKit
import Firebase

class TableViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var ref = DatabaseReference.init()
    var arrayofmodel = [Model]()
    static var indpath = Int()
    
    var currentUserArray = [Model]()
    var searching = false
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadFunctionality()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableview.backgroundView = UIImageView(image: UIImage(named: "bridgeWallpaper.png"))
        self.tableview.contentMode = .scaleToFill
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        getData()
    }
    
    
    
    
    //MARK:Load_functionality function
    func loadFunctionality(){
        self.ref = Database.database().reference()
            searchBar.delegate = self
        }
    
    
    //MARK:get_data function
    func getData(){
        self.arrayofmodel.removeAll()
        self.tableview.reloadData()
        self.ref.child("entryarray").queryOrderedByKey().observe(.value) { (snapshot) in
        
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot]{
                
                for snap in snapShot{
                    if let dic = snap.value as? [String:String]{
                        
                        let realn=dic["tf1"]
                        let friencall=dic["tf2"]
                        let birth=dic["tf3"]
                        let emai=dic["tf4"]
                        let best=dic["tf5"]
                        let happi=dic["tf6"]
                        let place=dic["tf7"]
                        let color=dic["tf8"]
                        let song=dic["tf9"]
                        let movie=dic["tf10"]
                        let luckyno=dic["tf11"]
                        let goodthing=dic["tf12"]
                        let badthings=dic["tf13"]
                        let threewishes=dic["tf14"]
                        let lifeishell=dic["tf15"]
                        let wrostmistake=dic["tf16"]
                        let describe=dic["tf17"]
                        let yourcomment=dic["tf18"]
                        let quote=dic["tf19"]
                        
                        self.arrayofmodel.append(Model(realname: realn!, friendscallme: friencall!, birthday: birth!, email: emai!, bestfriend: best!,happiestmomentoflife: happi!,placeyouwanttosee: place!,favouritecolor: color!,favouritesonf: song!,favouritemovie: movie!,luckynumber: luckyno!,goodthingsaboutyou: goodthing!,badthingsaboutyou: badthings!,ifyouaregrantedthreewishes: threewishes!,lifeishellwithout: lifeishell!,worstmistake: wrostmistake!,describewhatyoufeellikewaking: describe!,yourcommentaboutme: yourcomment!,favouritequote: quote!))

                        self.tableview.reloadData()
                        
                    }
                }
                
            }
        }
    }
    
    
    
    //MARK:Table_view_DataSourse function
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching{
            return self.currentUserArray.count
        }else{
            return self.arrayofmodel.count
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:TableViewCell = tableView.dequeueReusableCell(withIdentifier: "cell")as! TableViewCell
        
        if searching{
            cell.realnamelbl.text = self.currentUserArray[indexPath.row].realname
            cell.backgroundView = UIImageView(image: UIImage(named: "bridgeWallpaper.png"))
            cell.backgroundView?.contentMode = .scaleAspectFill
        }else{
            cell.realnamelbl.text = self.arrayofmodel[indexPath.row].realname
            cell.backgroundView = UIImageView(image: UIImage(named: "bridgeWallpaper.png"))
            cell.backgroundView?.contentMode = .scaleAspectFill
        }
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailvc:DetailViewController=self.storyboard?.instantiateViewController(identifier: "dvc")as! DetailViewController
        
        if searching{
            let temp = self.currentUserArray[indexPath.row]
            detailvc.strrealname = temp.realname
            detailvc.strfriencall  = temp.friendscallme
            detailvc.strbirth  = temp.birthday
            detailvc.stremai  = temp.email
            detailvc.strbest  = temp.bestfriend
            detailvc.strhappi  = temp.happiestmomentoflife
            detailvc.strplace  = temp.placeyouwanttosee
            detailvc.strcolor  = temp.favouritecolor
            detailvc.strsong  = temp.favouritesonf
            detailvc.strmovie  = temp.favouritemovie
            detailvc.strluckyno  = temp.luckynumber
            detailvc.strgoodthing  = temp.goodthingsaboutyou
            detailvc.strbadthings  = temp.badthingsaboutyou
            detailvc.strthreewishes  = temp.ifyouaregrantedthreewishes
            detailvc.strlifeishell  = temp.lifeishellwithout
            detailvc.strwrostmistake  = temp.worstmistake
            detailvc.strdescribe  = temp.describewhatyoufeellikewaking
            detailvc.stryourcomment  = temp.yourcommentaboutme
            detailvc.strquote  = temp.favouritequote
            
            TableViewController.indpath=indexPath.row
            //        print("indexpath= ",TableViewController.indpath)
            
        }else{
            let temp = self.arrayofmodel[indexPath.row]
            detailvc.strrealname = temp.realname
            detailvc.strfriencall  = temp.friendscallme
            detailvc.strbirth  = temp.birthday
            detailvc.stremai  = temp.email
            detailvc.strbest  = temp.bestfriend
            detailvc.strhappi  = temp.happiestmomentoflife
            detailvc.strplace  = temp.placeyouwanttosee
            detailvc.strcolor  = temp.favouritecolor
            detailvc.strsong  = temp.favouritesonf
            detailvc.strmovie  = temp.favouritemovie
            detailvc.strluckyno  = temp.luckynumber
            detailvc.strgoodthing  = temp.goodthingsaboutyou
            detailvc.strbadthings  = temp.badthingsaboutyou
            detailvc.strthreewishes  = temp.ifyouaregrantedthreewishes
            detailvc.strlifeishell  = temp.lifeishellwithout
            detailvc.strwrostmistake  = temp.worstmistake
            detailvc.strdescribe  = temp.describewhatyoufeellikewaking
            detailvc.stryourcomment  = temp.yourcommentaboutme
            detailvc.strquote  = temp.favouritequote

            TableViewController.indpath=indexPath.row
            //        print("indexpath= ",TableViewController.indpath)
            
        }
        self.navigationController?.pushViewController(detailvc, animated: true)
    }
    
}





extension TableViewController: UISearchBarDelegate{

    //MARK:Search_Bar_Delegate function
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        guard !searchText.isEmpty
            else{ currentUserArray = arrayofmodel; self.tableview.reloadData(); return }
        
        currentUserArray = arrayofmodel.filter { (user) -> Bool in
            return user.realname.lowercased().contains(searchText.lowercased())
        }
            //for currentModel in currentUserArray{
                //print(currentModel.realname)
            //}
            //print()
        searching = true
        self.tableview.reloadData()
        
    }
    
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
        searching = false
        self.tableview.reloadData()
    }
    
}
