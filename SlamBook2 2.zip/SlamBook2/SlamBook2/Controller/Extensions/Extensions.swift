//
//  Extensions.swift
//  SlamBook2
//
//  Created by Vinayak Balaji Tuptewar on 21/06/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//



import Foundation
import UIKit

extension UIViewController{
    
    //MARK:Alert Function
    func showAlert(title:String , message:String ){
        var alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
        
    }
    
}
