//
//  ModelClass.swift
//  SlamBook2
//
//  Created by Vinayak Balaji Tuptewar on 06/05/20.
//  Copyright © 2020 Vinayak Balaji Tuptewar. All rights reserved.
//

import Foundation

class Model {
    var realname: String
    var friendscallme: String
    var birthday: String
    var email: String
    var bestfriend: String
    var happiestmomentoflife: String
    var placeyouwanttosee: String
    var favouritecolor: String
    var favouritesonf: String
    var favouritemovie: String
    var luckynumber: String
    var goodthingsaboutyou: String
    var badthingsaboutyou: String
    var ifyouaregrantedthreewishes: String
    var lifeishellwithout: String
    var worstmistake: String
    var describewhatyoufeellikewaking: String
    var yourcommentaboutme: String
    var favouritequote: String
    
    init(realname: String,friendscallme: String,birthday: String,email: String ,bestfriend: String,happiestmomentoflife: String,placeyouwanttosee: String,favouritecolor: String,favouritesonf: String,favouritemovie: String,luckynumber: String,goodthingsaboutyou: String,badthingsaboutyou: String,ifyouaregrantedthreewishes: String,lifeishellwithout: String,worstmistake: String,describewhatyoufeellikewaking: String,yourcommentaboutme: String,favouritequote: String ) {
        
        self.realname=realname
        self.friendscallme=friendscallme
        self.birthday=birthday
        self.email=email
        self.bestfriend=bestfriend
        self.happiestmomentoflife=happiestmomentoflife
        self.placeyouwanttosee=placeyouwanttosee
        self.favouritecolor=favouritecolor
        self.favouritesonf=favouritesonf
        self.favouritemovie=favouritemovie
        self.luckynumber=luckynumber
        self.goodthingsaboutyou=goodthingsaboutyou
        self.badthingsaboutyou=badthingsaboutyou
        self.ifyouaregrantedthreewishes=ifyouaregrantedthreewishes
        self.lifeishellwithout=lifeishellwithout
        self.worstmistake=worstmistake
        self.describewhatyoufeellikewaking=describewhatyoufeellikewaking
        self.yourcommentaboutme=yourcommentaboutme
        self.favouritequote=favouritequote
    }
}


//MARK:temporary model for search bar
class tempModel{
    var name:String
    init(name:String) {
        self.name = name
    }
}
