import UIKit
import Firebase

class AddViewController: UIViewController,UITextFieldDelegate {
    
    var ref = DatabaseReference.init()
    let datepicker = UIDatePicker()
    
    @IBOutlet weak var realnametf: UITextField!
    @IBOutlet weak var friendscallmetf: UITextField!
    @IBOutlet weak var birthdaytf: UITextField!
    @IBOutlet weak var emailtf: UITextField!
    @IBOutlet weak var bestfriendtf: UITextField!
    @IBOutlet weak var happiestmomentoflifetf: UITextField!
    @IBOutlet weak var placeyouwanttoseetf: UITextField!
    @IBOutlet weak var favouritecolortf: UITextField!
    @IBOutlet weak var favouritesonftf: UITextField!
    @IBOutlet weak var favouritemovietf: UITextField!
    @IBOutlet weak var luckynumbertf: UITextField!
    @IBOutlet weak var goodthingsaboutyou: UITextField!
    @IBOutlet weak var badthingsaboutyoutf: UITextField!
    @IBOutlet weak var ifyouaregrantedthreewishestf: UITextField!
    @IBOutlet weak var lifeishellwithouttf: UITextField!
    @IBOutlet weak var worstmistaketf: UITextField!
    @IBOutlet weak var describewhatyoufeellikewakingtf: UITextField!
    @IBOutlet weak var yourcommentaboutmetf: UITextField!
    @IBOutlet weak var favouritequotetf: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ref = Database.database().reference()
        createdatepicker()
        loadFunctionality()
    }
    
    
    
    //MARK:Load Functionality
    func loadFunctionality(){
        realnametf.delegate = self
        friendscallmetf.delegate = self
        emailtf.delegate = self
        bestfriendtf.delegate = self
        happiestmomentoflifetf.delegate = self
        placeyouwanttoseetf.delegate = self
        favouritecolortf.delegate = self
        favouritesonftf.delegate = self
        favouritemovietf.delegate = self
        goodthingsaboutyou.delegate = self
        badthingsaboutyoutf.delegate = self
        ifyouaregrantedthreewishestf.delegate = self
        lifeishellwithouttf.delegate = self
        worstmistaketf.delegate = self
        describewhatyoufeellikewakingtf.delegate = self
        yourcommentaboutmetf.delegate = self
        favouritequotetf.delegate = self
    }
    
    
    
    //MARK: textFieldShouldReturn function
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        return textField.endEditing(true)
    }
    
    
    
    //MARK: create_date_picker function
    func createdatepicker(){
        
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(doneclick))
        toolbar.setItems([donebtn], animated: true)
        
        birthdaytf.inputAccessoryView = toolbar
        birthdaytf.inputView = datepicker
        
        datepicker.datePickerMode = .date
    }
    
    
    
    
    //MARK: done_click function
    @objc func doneclick(){
        if luckynumbertf.isFirstResponder{
            self.view.endEditing(true)
        }else if birthdaytf.isFirstResponder{
            let df = DateFormatter()
            //        df.dateFormat = "dd/MM/YYYY"
            df.dateStyle = .medium
            df.timeStyle = .none
            birthdaytf.text = df.string(from: datepicker.date)
            self.view.endEditing(true)
        }
    }
    
    //MARK: save_click function
    @IBAction func saveclick(_ sender: Any) {
        
        let tempdic = ["tf1":realnametf.text!,"tf2":friendscallmetf.text!,"tf3":birthdaytf.text!,"tf4":emailtf.text!,"tf5":bestfriendtf.text!,"tf6":happiestmomentoflifetf.text!,"tf7":placeyouwanttoseetf.text!,"tf8":favouritecolortf.text!,"tf9":favouritesonftf.text!,"tf10":favouritemovietf.text!,"tf11":luckynumbertf.text!,"tf12":goodthingsaboutyou.text!,"tf13":badthingsaboutyoutf.text!,"tf14":ifyouaregrantedthreewishestf.text!,"tf15":lifeishellwithouttf.text!,"tf16":worstmistaketf.text!,"tf17":describewhatyoufeellikewakingtf.text!,"tf18":yourcommentaboutmetf.text!,"tf19":favouritequotetf.text!]
        
        if realnametf.text != ""{
            self.ref.child("entryarray").childByAutoId().setValue(tempdic)
            self.navigationController?.popViewController(animated: true)
            //print("save clicked")
            
        }else{
            showAlert(title: "Alert", message: "Full name is mandatory")
        }
    }
    
}

































